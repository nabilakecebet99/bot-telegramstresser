while true
do
./uzer
done
